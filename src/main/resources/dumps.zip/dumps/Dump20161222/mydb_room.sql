-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `roomId` int(11) NOT NULL AUTO_INCREMENT,
  `hotelId` int(11) NOT NULL,
  `roomType` varchar(45) DEFAULT NULL,
  `roomTariff` varchar(45) DEFAULT NULL,
  `roomSts` varchar(45) DEFAULT NULL,
  `mdfyBy` varchar(45) DEFAULT NULL,
  `mdfyOn` datetime DEFAULT NULL,
  `roomNumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`roomId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,1,'Standard','1700','1','Atul','2016-12-08 02:17:43','101'),(2,2,'Standard','1899','1','Atul','2016-12-08 02:20:31','101'),(3,3,'Standard','1991','1','Atul','2016-12-08 02:20:31','101'),(4,4,'Standard','2000','1','Atul','2016-12-08 02:20:31','101'),(5,5,'Standard','2100','1','Atul','2016-12-08 02:20:31','101'),(6,6,'Standard','2500','1','Atul','2016-12-08 02:20:32','101'),(7,7,'Standard','2700','1','Atul','2016-12-08 02:20:32','101'),(8,8,'Standard','3000','1','Atul','2016-12-08 02:20:32','101'),(9,2,'Delux','13000','1','Atul','2016-12-08 02:22:59','102'),(10,2,'Premier','15000','1','Atul','2016-12-08 02:22:59','103'),(11,4,'Delux','12000','1','Atul','2016-12-08 02:22:59','202'),(12,4,'Premier','16000','1','Atul','2016-12-08 02:22:59','301'),(13,2,'Royel','19000','1','Atul','2016-12-08 02:22:59','202'),(14,4,'Royel','20000','1','Atul','2016-12-08 02:22:59','404');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-22 23:54:11
